const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");
const { DatabaseSync } = require("node:sqlite");
const { loadAppConfig } = require("./app-config");

const ROOT = __dirname;
const ENV_PATH = path.join(ROOT, ".env");

if (fs.existsSync(ENV_PATH)) {
  const envText = fs.readFileSync(ENV_PATH, "utf8");
  envText.split(/\r?\n/).forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      return;
    }

    const separatorIndex = trimmed.indexOf("=");
    if (separatorIndex === -1) {
      return;
    }

    const key = trimmed.slice(0, separatorIndex).trim();
    const value = trimmed.slice(separatorIndex + 1).trim();

    if (key && !process.env[key]) {
      process.env[key] = value;
    }
  });
}

const APP_CONFIG = loadAppConfig(ROOT);
const PORT = APP_CONFIG.port;
const HOST = APP_CONFIG.host;
const GEMINI_API_KEY = APP_CONFIG.geminiApiKey;
const GEMINI_MODEL = APP_CONFIG.geminiModel;
const ADMIN_USERNAME = APP_CONFIG.adminUsername;
const ADMIN_PASSWORD = APP_CONFIG.adminPassword;
const SESSION_COOKIE = APP_CONFIG.sessionCookie;
const DATA_DIR = APP_CONFIG.dataDir;
const DB_PATH = APP_CONFIG.dbPath;
const ALLOWED_ORIGINS = APP_CONFIG.allowedOrigins;
const RESEND_API_KEY = APP_CONFIG.resendApiKey;
const RESEND_FROM_EMAIL = APP_CONFIG.resendFromEmail;
const NOTIFY_EMAIL_TO = APP_CONFIG.notifyEmailTo;
const RAZORPAY_KEY_ID = APP_CONFIG.razorpayKeyId;
const RAZORPAY_KEY_SECRET = APP_CONFIG.razorpayKeySecret;
const APP_BASE_URL = APP_CONFIG.appBaseUrl;
const PUBLIC_API_BASE = APP_CONFIG.publicApiBase;

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const db = new DatabaseSync(DB_PATH);
const adminSessions = new Map();
const resendConfigured = Boolean(RESEND_API_KEY && RESEND_FROM_EMAIL && NOTIFY_EMAIL_TO);
const razorpayConfigured = Boolean(RAZORPAY_KEY_ID && RAZORPAY_KEY_SECRET);
const NURTURE_DELAYS_DAYS = [2, 5, 10];
let nurtureLoopActive = false;

const PRODUCT_CATALOG = [
  {
    id: "free-community-workshop",
    type: "free",
    category: "Community Workshop",
    name: "Free Community Workshop Pass",
    priceInr: 0,
    description:
      "An open-entry SkillNest community workshop for students, freshers, and knowledge seekers who want a low-risk first step.",
    includes: [
      "Live community workshop access",
      "Skill guidance from SkillNest AI",
      "Post-workshop next-step recommendations",
    ],
    ctaLabel: "Register Free",
  },
  {
    id: "paid-ai-workshop",
    type: "paid",
    category: "Paid Workshop",
    name: "AI Career Starter Workshop",
    priceInr: 1499,
    description:
      "A paid practical workshop focused on AI fundamentals, tool exposure, guided exercises, and clearer career direction.",
    includes: [
      "Guided live workshop",
      "Practical exercises and assignments",
      "Learner dashboard access and onboarding",
    ],
    ctaLabel: "Pay & Enroll",
  },
  {
    id: "paid-cloud-workshop",
    type: "paid",
    category: "Paid Workshop",
    name: "Cloud Foundations Workshop",
    priceInr: 1999,
    description:
      "A hands-on cloud workshop for learners who want stronger practical clarity before moving into deeper training paths.",
    includes: [
      "Structured workshop delivery",
      "Foundational cloud roadmap",
      "Access to onboarding and next-step guidance",
    ],
    ctaLabel: "Pay & Enroll",
  },
];

function createPasswordHash(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derivedKey = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derivedKey}`;
}

function verifyPassword(password, storedHash) {
  if (!storedHash || !storedHash.includes(":")) {
    return false;
  }

  const [salt, originalKey] = storedHash.split(":");
  const derivedKey = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(derivedKey, "hex"), Buffer.from(originalKey, "hex"));
}

function toIsoDateOffset(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toISOString();
}

function nowIso() {
  return new Date().toISOString();
}

function getProductById(productId) {
  return PRODUCT_CATALOG.find((product) => product.id === productId) || null;
}

function getBaseUrl(request) {
  if (APP_BASE_URL) {
    return APP_BASE_URL.replace(/\/$/, "");
  }

  if (!request) {
    return "";
  }

  const proto = request.headers["x-forwarded-proto"] || "http";
  const host = request.headers.host || "";
  return host ? `${proto}://${host}` : "";
}

function buildRuntimeClientConfig(request) {
  const baseUrl = PUBLIC_API_BASE || "";
  return `window.SKILLNEST_CONFIG = window.SKILLNEST_CONFIG || ${JSON.stringify(
    {
      apiBase: baseUrl,
      runtimeMode: APP_CONFIG.runtimeMode,
      platformTarget: APP_CONFIG.platformTarget,
    },
    null,
    2
  )};\n`;
}

db.exec(`
  CREATE TABLE IF NOT EXISTS contact_inquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    organization TEXT,
    interest TEXT NOT NULL,
    message TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'contact_form',
    ai_score INTEGER NOT NULL DEFAULT 0,
    ai_summary TEXT NOT NULL DEFAULT '',
    ai_next_step TEXT NOT NULL DEFAULT '',
    ai_followup_subject TEXT NOT NULL DEFAULT '',
    ai_followup_body TEXT NOT NULL DEFAULT '',
    ai_followup_sent INTEGER NOT NULL DEFAULT 0,
    nurture_stage INTEGER NOT NULL DEFAULT 0,
    nurture_next_run_at TEXT NOT NULL DEFAULT '',
    nurture_last_sent_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS chatbot_leads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    name TEXT NOT NULL,
    contact TEXT NOT NULL,
    learner_type TEXT NOT NULL,
    interest TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new',
    notes TEXT NOT NULL DEFAULT '',
    ai_score INTEGER NOT NULL DEFAULT 0,
    ai_summary TEXT NOT NULL DEFAULT '',
    ai_next_step TEXT NOT NULL DEFAULT '',
    ai_followup_subject TEXT NOT NULL DEFAULT '',
    ai_followup_body TEXT NOT NULL DEFAULT '',
    ai_followup_sent INTEGER NOT NULL DEFAULT 0,
    nurture_stage INTEGER NOT NULL DEFAULT 0,
    nurture_next_run_at TEXT NOT NULL DEFAULT '',
    nurture_last_sent_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS workshops (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    type TEXT NOT NULL,
    description TEXT NOT NULL,
    schedule_text TEXT NOT NULL,
    duration_text TEXT NOT NULL,
    level_text TEXT NOT NULL,
    cta_text TEXT NOT NULL,
    cta_link TEXT NOT NULL,
    ai_workshop_description TEXT NOT NULL DEFAULT '',
    ai_announcement TEXT NOT NULL DEFAULT '',
    ai_social_posts TEXT NOT NULL DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS enrollments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id TEXT NOT NULL,
    product_name TEXT NOT NULL,
    product_type TEXT NOT NULL,
    amount_inr INTEGER NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT 'INR',
    learner_name TEXT NOT NULL,
    learner_email TEXT NOT NULL,
    learner_phone TEXT NOT NULL,
    learner_type TEXT NOT NULL,
    learner_goal TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    payment_provider TEXT NOT NULL DEFAULT '',
    provider_order_id TEXT NOT NULL DEFAULT '',
    provider_payment_id TEXT NOT NULL DEFAULT '',
    provider_signature TEXT NOT NULL DEFAULT '',
    access_token TEXT NOT NULL UNIQUE,
    onboarding_sent INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

function ensureColumn(tableName, columnName, columnDefinition) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  const exists = columns.some((column) => column.name === columnName);
  if (!exists) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDefinition}`);
  }
}

ensureColumn("chatbot_leads", "status", "TEXT NOT NULL DEFAULT 'new'");
ensureColumn("chatbot_leads", "notes", "TEXT NOT NULL DEFAULT ''");
ensureColumn("chatbot_leads", "updated_at", "TEXT");
ensureColumn("chatbot_leads", "ai_score", "INTEGER NOT NULL DEFAULT 0");
ensureColumn("chatbot_leads", "ai_summary", "TEXT NOT NULL DEFAULT ''");
ensureColumn("chatbot_leads", "ai_next_step", "TEXT NOT NULL DEFAULT ''");
ensureColumn("chatbot_leads", "ai_followup_subject", "TEXT NOT NULL DEFAULT ''");
ensureColumn("chatbot_leads", "ai_followup_body", "TEXT NOT NULL DEFAULT ''");
ensureColumn("chatbot_leads", "ai_followup_sent", "INTEGER NOT NULL DEFAULT 0");
ensureColumn("chatbot_leads", "nurture_stage", "INTEGER NOT NULL DEFAULT 0");
ensureColumn("chatbot_leads", "nurture_next_run_at", "TEXT NOT NULL DEFAULT ''");
ensureColumn("chatbot_leads", "nurture_last_sent_at", "TEXT NOT NULL DEFAULT ''");
ensureColumn("contact_inquiries", "ai_score", "INTEGER NOT NULL DEFAULT 0");
ensureColumn("contact_inquiries", "ai_summary", "TEXT NOT NULL DEFAULT ''");
ensureColumn("contact_inquiries", "ai_next_step", "TEXT NOT NULL DEFAULT ''");
ensureColumn("contact_inquiries", "ai_followup_subject", "TEXT NOT NULL DEFAULT ''");
ensureColumn("contact_inquiries", "ai_followup_body", "TEXT NOT NULL DEFAULT ''");
ensureColumn("contact_inquiries", "ai_followup_sent", "INTEGER NOT NULL DEFAULT 0");
ensureColumn("contact_inquiries", "nurture_stage", "INTEGER NOT NULL DEFAULT 0");
ensureColumn("contact_inquiries", "nurture_next_run_at", "TEXT NOT NULL DEFAULT ''");
ensureColumn("contact_inquiries", "nurture_last_sent_at", "TEXT NOT NULL DEFAULT ''");
ensureColumn("workshops", "ai_workshop_description", "TEXT NOT NULL DEFAULT ''");
ensureColumn("workshops", "ai_announcement", "TEXT NOT NULL DEFAULT ''");
ensureColumn("workshops", "ai_social_posts", "TEXT NOT NULL DEFAULT ''");
db.exec(`
  UPDATE chatbot_leads
  SET updated_at = COALESCE(updated_at, created_at),
      status = COALESCE(status, 'new'),
      notes = COALESCE(notes, ''),
      ai_score = COALESCE(ai_score, 0),
      ai_summary = COALESCE(ai_summary, ''),
      ai_next_step = COALESCE(ai_next_step, ''),
      ai_followup_subject = COALESCE(ai_followup_subject, ''),
      ai_followup_body = COALESCE(ai_followup_body, ''),
      ai_followup_sent = COALESCE(ai_followup_sent, 0),
      nurture_stage = COALESCE(nurture_stage, 0),
      nurture_next_run_at = COALESCE(nurture_next_run_at, ''),
      nurture_last_sent_at = COALESCE(nurture_last_sent_at, '')
`);
db.exec(`
  UPDATE contact_inquiries
  SET ai_score = COALESCE(ai_score, 0),
      ai_summary = COALESCE(ai_summary, ''),
      ai_next_step = COALESCE(ai_next_step, ''),
      ai_followup_subject = COALESCE(ai_followup_subject, ''),
      ai_followup_body = COALESCE(ai_followup_body, ''),
      ai_followup_sent = COALESCE(ai_followup_sent, 0),
      nurture_stage = COALESCE(nurture_stage, 0),
      nurture_next_run_at = COALESCE(nurture_next_run_at, ''),
      nurture_last_sent_at = COALESCE(nurture_last_sent_at, '')
`);
db.exec(`
  UPDATE contact_inquiries
  SET nurture_next_run_at = datetime('now', '+2 day'),
      nurture_last_sent_at = COALESCE(NULLIF(nurture_last_sent_at, ''), CURRENT_TIMESTAMP)
  WHERE ai_followup_sent = 1 AND nurture_stage = 0 AND nurture_next_run_at = ''
`);
db.exec(`
  UPDATE workshops
  SET ai_workshop_description = COALESCE(ai_workshop_description, ''),
      ai_announcement = COALESCE(ai_announcement, ''),
      ai_social_posts = COALESCE(ai_social_posts, '')
`);
db.exec(`
  UPDATE chatbot_leads
  SET nurture_next_run_at = datetime('now', '+2 day'),
      nurture_last_sent_at = COALESCE(NULLIF(nurture_last_sent_at, ''), CURRENT_TIMESTAMP)
  WHERE ai_followup_sent = 1 AND nurture_stage = 0 AND nurture_next_run_at = ''
`);

const insertInquiry = db.prepare(`
  INSERT INTO contact_inquiries (name, email, organization, interest, message, source, ai_score, ai_summary, ai_next_step, ai_followup_subject, ai_followup_body, ai_followup_sent, nurture_stage, nurture_next_run_at, nurture_last_sent_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const selectAdminUser = db.prepare(`
  SELECT id, username, password_hash, created_at, updated_at
  FROM admin_users
  ORDER BY id ASC
  LIMIT 1
`);
const insertAdminUser = db.prepare(`
  INSERT INTO admin_users (username, password_hash)
  VALUES (?, ?)
`);
const updateAdminPassword = db.prepare(`
  UPDATE admin_users
  SET password_hash = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);
const insertLead = db.prepare(`
  INSERT INTO chatbot_leads (session_id, name, contact, learner_type, interest, status, notes, ai_score, ai_summary, ai_next_step, ai_followup_subject, ai_followup_body, ai_followup_sent, nurture_stage, nurture_next_run_at, nurture_last_sent_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const insertChatMessage = db.prepare(`
  INSERT INTO chat_messages (session_id, role, content)
  VALUES (?, ?, ?)
`);
const selectInquiryCount = db.prepare(`SELECT COUNT(*) AS count FROM contact_inquiries`);
const selectLeadCount = db.prepare(`SELECT COUNT(*) AS count FROM chatbot_leads`);
const selectChatCount = db.prepare(`SELECT COUNT(*) AS count FROM chat_messages`);
const selectWorkshopCount = db.prepare(`SELECT COUNT(*) AS count FROM workshops`);
const selectEnrollmentCount = db.prepare(`SELECT COUNT(*) AS count FROM enrollments`);
const selectRecentInquiries = db.prepare(`
  SELECT id, name, email, organization, interest, message, source, ai_score, ai_summary, ai_next_step, ai_followup_subject, ai_followup_body, ai_followup_sent, nurture_stage, nurture_next_run_at, nurture_last_sent_at, created_at
  FROM contact_inquiries
  ORDER BY id DESC
  LIMIT 20
`);
const selectRecentLeads = db.prepare(`
  SELECT id, session_id, name, contact, learner_type, interest, status, notes, ai_score, ai_summary, ai_next_step, ai_followup_subject, ai_followup_body, ai_followup_sent, nurture_stage, nurture_next_run_at, nurture_last_sent_at, created_at, updated_at
  FROM chatbot_leads
  ORDER BY id DESC
  LIMIT 20
`);
const selectRecentChats = db.prepare(`
  SELECT id, session_id, role, content, created_at
  FROM chat_messages
  ORDER BY id DESC
  LIMIT 30
`);
const selectWorkshops = db.prepare(`
  SELECT id, title, type, description, schedule_text, duration_text, level_text, cta_text, cta_link, ai_workshop_description, ai_announcement, ai_social_posts, is_active, created_at, updated_at
  FROM workshops
  ORDER BY id DESC
`);
const selectPublicWorkshops = db.prepare(`
  SELECT id, title, type, description, schedule_text, duration_text, level_text, cta_text, cta_link
  FROM workshops
  WHERE is_active = 1
  ORDER BY id DESC
`);
const insertWorkshop = db.prepare(`
  INSERT INTO workshops (title, type, description, schedule_text, duration_text, level_text, cta_text, cta_link, ai_workshop_description, ai_announcement, ai_social_posts, is_active)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const updateWorkshop = db.prepare(`
  UPDATE workshops
  SET title = ?, type = ?, description = ?, schedule_text = ?, duration_text = ?, level_text = ?, cta_text = ?, cta_link = ?, ai_workshop_description = ?, ai_announcement = ?, ai_social_posts = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);
const selectWorkshopById = db.prepare(`
  SELECT id, title, type, description, schedule_text, duration_text, level_text, cta_text, cta_link, is_active
  FROM workshops
  WHERE id = ?
`);
const deleteWorkshop = db.prepare(`DELETE FROM workshops WHERE id = ?`);
const updateLeadStatus = db.prepare(`
  UPDATE chatbot_leads
  SET status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);
const insertEnrollment = db.prepare(`
  INSERT INTO enrollments (
    product_id,
    product_name,
    product_type,
    amount_inr,
    currency,
    learner_name,
    learner_email,
    learner_phone,
    learner_type,
    learner_goal,
    status,
    payment_provider,
    provider_order_id,
    access_token,
    onboarding_sent
  )
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const updateEnrollmentOrder = db.prepare(`
  UPDATE enrollments
  SET provider_order_id = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);
const updateEnrollmentPayment = db.prepare(`
  UPDATE enrollments
  SET status = ?, provider_payment_id = ?, provider_signature = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);
const updateEnrollmentOnboarding = db.prepare(`
  UPDATE enrollments
  SET onboarding_sent = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);
const selectEnrollmentById = db.prepare(`
  SELECT *
  FROM enrollments
  WHERE id = ?
`);
const selectEnrollmentByToken = db.prepare(`
  SELECT *
  FROM enrollments
  WHERE access_token = ?
`);
const selectRecentEnrollments = db.prepare(`
  SELECT *
  FROM enrollments
  ORDER BY id DESC
  LIMIT 20
`);
const selectDueInquiryNurtures = db.prepare(`
  SELECT id, name, email, organization, interest, message, ai_summary, ai_next_step, nurture_stage, nurture_next_run_at
  FROM contact_inquiries
  WHERE ai_followup_sent = 1 AND nurture_next_run_at != '' AND nurture_next_run_at <= ?
  ORDER BY id ASC
  LIMIT 10
`);
const selectDueLeadNurtures = db.prepare(`
  SELECT id, name, contact, learner_type, interest, status, ai_summary, ai_next_step, nurture_stage, nurture_next_run_at
  FROM chatbot_leads
  WHERE ai_followup_sent = 1 AND nurture_next_run_at != '' AND nurture_next_run_at <= ?
  ORDER BY id ASC
  LIMIT 10
`);
const updateInquiryNurture = db.prepare(`
  UPDATE contact_inquiries
  SET nurture_stage = ?, nurture_next_run_at = ?, nurture_last_sent_at = ?
  WHERE id = ?
`);
const updateLeadNurture = db.prepare(`
  UPDATE chatbot_leads
  SET nurture_stage = ?, nurture_next_run_at = ?, nurture_last_sent_at = ?, updated_at = CURRENT_TIMESTAMP
  WHERE id = ?
`);

function seedAdminUserIfNeeded() {
  const existingAdmin = selectAdminUser.get();
  if (existingAdmin) {
    return;
  }

  insertAdminUser.run(ADMIN_USERNAME, createPasswordHash(ADMIN_PASSWORD));
}

function seedWorkshopsIfNeeded() {
  if (selectWorkshopCount.get().count > 0) {
    return;
  }

  const seedRows = [
    [
      "Cloud Basics for College Students",
      "Free Workshop",
      "Introductory session covering cloud concepts, career paths, and practical starting points.",
      "Saturday, 10:00 AM",
      "2 Hours",
      "Beginner",
      "Reserve Seat",
      "contact.html",
      "",
      "",
      "",
      1,
    ],
    [
      "Hands-On Data Analysis Sprint",
      "Paid Workshop",
      "Learn practical data workflows, basic tools, and how to think analytically with guided exercises.",
      "Sunday, 11:30 AM",
      "3 Hours",
      "Beginner to Intermediate",
      "Enroll Now",
      "contact.html",
      "",
      "",
      "",
      1,
    ],
    [
      "Introduction to AI Tools and Use Cases",
      "Free Workshop",
      "Explore AI ideas, practical examples, and how students and freshers can start learning responsibly.",
      "Wednesday, 5:00 PM",
      "90 Minutes",
      "Beginner",
      "Reserve Seat",
      "contact.html",
      "",
      "",
      "",
      1,
    ],
    [
      "Cybersecurity Awareness and Foundations",
      "Paid Workshop",
      "Understand security basics, threat awareness, and how cybersecurity skills connect to career growth.",
      "Saturday, 4:00 PM",
      "2.5 Hours",
      "Beginner",
      "Enroll Now",
      "contact.html",
      "",
      "",
      "",
      1,
    ],
  ];

  seedRows.forEach((row) => insertWorkshop.run(...row));
}

seedAdminUserIfNeeded();
seedWorkshopsIfNeeded();

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

function applyCors(request, response) {
  const requestOrigin = request.headers.origin;
  if (!requestOrigin) {
    return;
  }

  const allowed =
    ALLOWED_ORIGINS.includes("*") ||
    ALLOWED_ORIGINS.includes(requestOrigin) ||
    requestOrigin === `http://${request.headers.host}` ||
    requestOrigin === `https://${request.headers.host}`;

  if (!allowed) {
    return;
  }

  response.setHeader("Access-Control-Allow-Origin", requestOrigin);
  response.setHeader("Vary", "Origin");
  response.setHeader("Access-Control-Allow-Credentials", "true");
  response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
}

function sendJson(response, statusCode, body, extraHeaders = {}) {
  response.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    ...extraHeaders,
  });
  response.end(JSON.stringify(body));
}

function sendText(response, statusCode, text, contentType = "text/plain; charset=utf-8", extraHeaders = {}) {
  response.writeHead(statusCode, {
    "Content-Type": contentType,
    ...extraHeaders,
  });
  response.end(text);
}

function readRequestBody(request) {
  return new Promise((resolve, reject) => {
    let data = "";

    request.on("data", (chunk) => {
      data += chunk;
      if (data.length > 1_000_000) {
        reject(new Error("Request body too large."));
        request.destroy();
      }
    });

    request.on("end", () => resolve(data));
    request.on("error", reject);
  });
}

async function parseJsonBody(request) {
  const rawBody = await readRequestBody(request);
  return rawBody ? JSON.parse(rawBody) : {};
}

function getSafeFilePath(urlPathname) {
  const normalizedPath = urlPathname === "/" ? "/index.html" : urlPathname;
  const cleanPath = path.normalize(decodeURIComponent(normalizedPath)).replace(/^(\.\.[/\\])+/, "");
  return path.join(ROOT, cleanPath);
}

function parseCookies(request) {
  const cookieHeader = request.headers.cookie || "";
  return cookieHeader.split(";").reduce((accumulator, chunk) => {
    const [key, ...rest] = chunk.trim().split("=");
    if (!key) {
      return accumulator;
    }
    accumulator[key] = decodeURIComponent(rest.join("="));
    return accumulator;
  }, {});
}

function getAdminSession(request) {
  const authorization = request.headers.authorization || "";
  const headerToken = authorization.startsWith("Bearer ")
    ? authorization.slice("Bearer ".length).trim()
    : "";
  const cookies = parseCookies(request);
  const token = headerToken || cookies[SESSION_COOKIE];
  if (!token) {
    return null;
  }

  return adminSessions.get(token) || null;
}

function requireAdmin(request, response) {
  const session = getAdminSession(request);
  if (!session) {
    sendJson(response, 401, { error: "Unauthorized" });
    return null;
  }
  return session;
}

function escapeCsv(value) {
  const stringValue = String(value ?? "");
  if (/[",\n]/.test(stringValue)) {
    return `"${stringValue.replace(/"/g, '""')}"`;
  }
  return stringValue;
}

function toCsv(rows) {
  if (!rows.length) {
    return "";
  }

  const headers = Object.keys(rows[0]);
  const headerLine = headers.map(escapeCsv).join(",");
  const dataLines = rows.map((row) => headers.map((header) => escapeCsv(row[header])).join(","));
  return [headerLine, ...dataLines].join("\n");
}

function extractGeminiText(payload) {
  if (!Array.isArray(payload?.candidates)) {
    return "";
  }

  const firstCandidate = payload.candidates[0];
  const parts = firstCandidate?.content?.parts;

  if (!Array.isArray(parts)) {
    return "";
  }

  return parts
    .map((part) => (typeof part?.text === "string" ? part.text : ""))
    .join("\n")
    .trim();
}

async function sendNotificationEmail({ subject, text, html }) {
  if (!resendConfigured) {
    return false;
  }
  const resendResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: RESEND_FROM_EMAIL,
      to: [NOTIFY_EMAIL_TO],
      subject,
      text,
      html,
    }),
  });

  const resendPayload = await resendResponse.json();
  if (!resendResponse.ok) {
    throw new Error(resendPayload?.message || resendPayload?.error || "Resend request failed.");
  }

  return true;
}

async function sendTransactionalEmail({ to, subject, text, html }) {
  if (!resendConfigured || !to) {
    return false;
  }

  const resendResponse = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: RESEND_FROM_EMAIL,
      to: [to],
      subject,
      text,
      html,
    }),
  });

  const resendPayload = await resendResponse.json();
  if (!resendResponse.ok) {
    throw new Error(resendPayload?.message || resendPayload?.error || "Resend request failed.");
  }

  return true;
}

async function createRazorpayOrder({ amountInr, receipt, notes }) {
  const auth = Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString("base64");
  const response = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: amountInr * 100,
      currency: "INR",
      receipt,
      notes,
    }),
  });

  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload?.error?.description || payload?.error?.reason || "Unable to create Razorpay order.");
  }

  return payload;
}

function verifyRazorpaySignature({ orderId, paymentId, signature }) {
  const digest = crypto
    .createHmac("sha256", RAZORPAY_KEY_SECRET)
    .update(`${orderId}|${paymentId}`)
    .digest("hex");

  return digest === signature;
}

async function notifyInquirySaved({ name, email, organization, interest, message, source, inquiryId, aiSummary, aiNextStep }) {
  try {
    await sendNotificationEmail({
      subject: `SkillNest inquiry #${inquiryId}: ${interest}`,
      text:
        `A new SkillNest inquiry was saved.\n\n` +
        `Inquiry ID: ${inquiryId}\n` +
        `Name: ${name}\n` +
        `Email: ${email}\n` +
        `Organization: ${organization || "Not provided"}\n` +
        `Interest: ${interest}\n` +
        `Source: ${source}\n\n` +
        `AI Summary: ${aiSummary || "Not generated"}\n` +
        `AI Next Step: ${aiNextStep || "Not generated"}\n\n` +
        `Message:\n${message}`,
      html:
        `<h2>New SkillNest inquiry</h2>` +
        `<p><strong>Inquiry ID:</strong> ${inquiryId}</p>` +
        `<p><strong>Name:</strong> ${name}</p>` +
        `<p><strong>Email:</strong> ${email}</p>` +
        `<p><strong>Organization:</strong> ${organization || "Not provided"}</p>` +
        `<p><strong>Interest:</strong> ${interest}</p>` +
        `<p><strong>Source:</strong> ${source}</p>` +
        `<p><strong>AI Summary:</strong> ${aiSummary || "Not generated"}</p>` +
        `<p><strong>AI Next Step:</strong> ${aiNextStep || "Not generated"}</p>` +
        `<p><strong>Message:</strong><br>${message.replace(/\n/g, "<br>")}</p>`,
    });
  } catch (error) {
    console.error("Inquiry notification failed:", error);
  }
}

async function notifyLeadSaved({ name, contact, learnerType, interest, leadId, status, aiSummary, aiNextStep }) {
  try {
    await sendNotificationEmail({
      subject: `SkillNest chatbot lead #${leadId}: ${interest}`,
      text:
        `A new chatbot lead was saved.\n\n` +
        `Lead ID: ${leadId}\n` +
        `Name: ${name}\n` +
        `Contact: ${contact}\n` +
        `Learner Type: ${learnerType}\n` +
        `Interest: ${interest}\n` +
        `Status: ${status}\n` +
        `AI Summary: ${aiSummary || "Not generated"}\n` +
        `AI Next Step: ${aiNextStep || "Not generated"}`,
      html:
        `<h2>New SkillNest chatbot lead</h2>` +
        `<p><strong>Lead ID:</strong> ${leadId}</p>` +
        `<p><strong>Name:</strong> ${name}</p>` +
        `<p><strong>Contact:</strong> ${contact}</p>` +
        `<p><strong>Learner Type:</strong> ${learnerType}</p>` +
        `<p><strong>Interest:</strong> ${interest}</p>` +
        `<p><strong>Status:</strong> ${status}</p>` +
        `<p><strong>AI Summary:</strong> ${aiSummary || "Not generated"}</p>` +
        `<p><strong>AI Next Step:</strong> ${aiNextStep || "Not generated"}</p>`,
    });
  } catch (error) {
    console.error("Lead notification failed:", error);
  }
}

function extractEmailAddress(value) {
  const text = String(value || "").trim();
  return text.includes("@") ? text : "";
}

async function sendAutomatedFollowup({ to, subject, body }) {
  if (!to || !subject || !body) {
    return false;
  }

  try {
    await sendTransactionalEmail({
      to,
      subject,
      text: body,
      html: `<p>${body.replace(/\n/g, "<br>")}</p>`,
    });
    return true;
  } catch (error) {
    console.error("Automated follow-up failed:", error);
    return false;
  }
}

async function sendLearnerOnboardingEmail({ request, enrollment }) {
  if (!enrollment?.learner_email) {
    return false;
  }

  const baseUrl = getBaseUrl(request);
  const dashboardLink = baseUrl
    ? `${baseUrl}/learner-dashboard.html?token=${encodeURIComponent(enrollment.access_token)}`
    : `learner-dashboard.html?token=${encodeURIComponent(enrollment.access_token)}`;

  const subject = `Welcome to ${enrollment.product_name}`;
  const text =
    `Hi ${enrollment.learner_name},\n\n` +
    `Your SkillNest enrollment is confirmed for ${enrollment.product_name}.\n` +
    `Use your learner dashboard here: ${dashboardLink}\n\n` +
    `We will guide you through the next steps, onboarding, and workshop readiness from there.\n\n` +
    `SkillNest\nKnowledge is the power.`;

  const html =
    `<p>Hi ${enrollment.learner_name},</p>` +
    `<p>Your SkillNest enrollment is confirmed for <strong>${enrollment.product_name}</strong>.</p>` +
    `<p><a href="${dashboardLink}">Open your learner dashboard</a></p>` +
    `<p>We will guide you through the next steps, onboarding, and workshop readiness from there.</p>` +
    `<p>SkillNest<br>Knowledge is the power.</p>`;

  try {
    await sendTransactionalEmail({
      to: enrollment.learner_email,
      subject,
      text,
      html,
    });
    updateEnrollmentOnboarding.run(1, enrollment.id);
    return true;
  } catch (error) {
    console.error("Learner onboarding email failed:", error);
    return false;
  }
}

function buildInquiryNurtureMessage(record) {
  const stage = Number(record.nurture_stage || 0) + 1;
  const subject = stage === 1
    ? `Still exploring ${record.interest}? SkillNest can guide you`
    : stage === 2
      ? `A clearer next step for your ${record.interest} journey`
      : `Last follow-up from SkillNest on ${record.interest}`;
  const body =
    `Hi ${record.name},\n\n` +
    `We wanted to follow up on your interest in ${record.interest}. ` +
    `${record.ai_summary || "You reached out to SkillNest for guidance."}\n\n` +
    `Recommended next step: ${record.ai_next_step || "Start with a guided conversation so we can suggest the right path."}\n\n` +
    `If you would like, reply to this email or reach us on WhatsApp/Contact and we will help you choose the best starting point.\n\n` +
    `SkillNest\nKnowledge is the power.`;

  return { subject, body };
}

function buildLeadNurtureMessage(record) {
  const stage = Number(record.nurture_stage || 0) + 1;
  const subject = stage === 1
    ? `SkillNest follow-up for your ${record.interest} interest`
    : stage === 2
      ? `A practical next step for your ${record.interest} goals`
      : `Checking in from SkillNest`;
  const body =
    `Hi ${record.name},\n\n` +
    `You recently showed interest in ${record.interest} at SkillNest. ` +
    `${record.ai_summary || "We wanted to make sure you have a clear next step."}\n\n` +
    `Suggested next move: ${record.ai_next_step || "Talk with SkillNest so we can recommend the right workshop or training."}\n\n` +
    `If you are ready, reply here or connect through WhatsApp/Contact and we will guide you personally.\n\n` +
    `SkillNest\nKnowledge is the power.`;

  return { subject, body };
}

async function runNurtureCycle() {
  if (nurtureLoopActive || !resendConfigured) {
    return;
  }

  nurtureLoopActive = true;

  try {
    const currentTime = nowIso();
    const dueInquiries = selectDueInquiryNurtures.all(currentTime);
    for (const inquiry of dueInquiries) {
      const { subject, body } = buildInquiryNurtureMessage(inquiry);
      const sent = await sendAutomatedFollowup({
        to: inquiry.email,
        subject,
        body,
      });

      if (!sent) {
        continue;
      }

      const nextStage = Number(inquiry.nurture_stage || 0) + 1;
      const nextRunAt =
        nextStage >= NURTURE_DELAYS_DAYS.length ? "" : toIsoDateOffset(NURTURE_DELAYS_DAYS[nextStage]);
      updateInquiryNurture.run(nextStage, nextRunAt, nowIso(), inquiry.id);
    }

    const dueLeads = selectDueLeadNurtures.all(currentTime);
    for (const lead of dueLeads) {
      const email = extractEmailAddress(lead.contact);
      if (!email) {
        updateLeadNurture.run(Number(lead.nurture_stage || 0) + 1, "", nowIso(), lead.id);
        continue;
      }

      const { subject, body } = buildLeadNurtureMessage(lead);
      const sent = await sendAutomatedFollowup({
        to: email,
        subject,
        body,
      });

      if (!sent) {
        continue;
      }

      const nextStage = Number(lead.nurture_stage || 0) + 1;
      const nextRunAt =
        nextStage >= NURTURE_DELAYS_DAYS.length ? "" : toIsoDateOffset(NURTURE_DELAYS_DAYS[nextStage]);
      updateLeadNurture.run(nextStage, nextRunAt, nowIso(), lead.id);
    }
  } catch (error) {
    console.error("Nurture cycle failed:", error);
  } finally {
    nurtureLoopActive = false;
  }
}

async function callGemini({ instructions, contents }) {
  const geminiResponse = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
      },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{ text: instructions }],
        },
        contents,
      }),
    }
  );

  const payload = await geminiResponse.json();

  if (!geminiResponse.ok) {
    throw new Error(payload?.error?.message || "Gemini request failed.");
  }

  return extractGeminiText(payload) || "";
}

async function generateInquiryAutomation({ name, organization, interest, message }) {
  if (!GEMINI_API_KEY) {
    return { aiScore: 0, aiSummary: "", aiNextStep: "", aiFollowupSubject: "", aiFollowupBody: "" };
  }

  const output = await callGemini({
    instructions:
      "You are SkillNest's internal AI intake assistant. " +
      "Summarize incoming inquiries for admins. " +
      "Return exactly these lines: SCORE: ..., SUMMARY: ..., NEXT_STEP: ..., FOLLOWUP_SUBJECT: ..., FOLLOWUP_BODY: ... " +
      "Use an integer score from 1 to 100. " +
      "Keep summary and next step concise, practical, and actionable. " +
      "The follow-up should be a short email body from SkillNest that warmly guides the learner to the best next step. " +
      "Do not invent details.",
    contents: [
      {
        role: "user",
        parts: [
          {
            text:
              `Name: ${name}\n` +
              `Organization: ${organization || "Not provided"}\n` +
              `Interest: ${interest}\n` +
              `Message: ${message}\n`,
          },
        ],
      },
    ],
  });

  const scoreMatch = output.match(/SCORE:\s*(\d+)/i);
  const summaryMatch = output.match(/SUMMARY:\s*(.+)/i);
  const nextStepMatch = output.match(/NEXT_STEP:\s*(.+)/i);
  const subjectMatch = output.match(/FOLLOWUP_SUBJECT:\s*(.+)/i);
  const bodyMatch = output.match(/FOLLOWUP_BODY:\s*([\s\S]*)$/i);

  return {
    aiScore: Number(scoreMatch?.[1] || 0),
    aiSummary: summaryMatch?.[1]?.trim() || "",
    aiNextStep: nextStepMatch?.[1]?.trim() || "",
    aiFollowupSubject: subjectMatch?.[1]?.trim() || "",
    aiFollowupBody: bodyMatch?.[1]?.trim() || "",
  };
}

async function generateLeadAutomation({ name, learnerType, interest, contact }) {
  if (!GEMINI_API_KEY) {
    return { aiScore: 0, aiSummary: "", aiNextStep: "", aiFollowupSubject: "", aiFollowupBody: "" };
  }

  const output = await callGemini({
    instructions:
      "You are SkillNest's internal AI lead triage assistant. " +
      "Summarize a lead and recommend the best next step for the SkillNest team. " +
      "Return exactly these lines: SCORE: ..., SUMMARY: ..., NEXT_STEP: ..., FOLLOWUP_SUBJECT: ..., FOLLOWUP_BODY: ... " +
      "Use an integer score from 1 to 100. " +
      "Keep the advice actionable and short. " +
      "The follow-up should be a short outreach email from SkillNest that matches the lead's learner type and interest. " +
      "Do not invent fees, dates, or commitments.",
    contents: [
      {
        role: "user",
        parts: [
          {
            text:
              `Name: ${name}\n` +
              `Learner type: ${learnerType}\n` +
              `Interest: ${interest}\n` +
              `Contact: ${contact}\n`,
          },
        ],
      },
    ],
  });

  const scoreMatch = output.match(/SCORE:\s*(\d+)/i);
  const summaryMatch = output.match(/SUMMARY:\s*(.+)/i);
  const nextStepMatch = output.match(/NEXT_STEP:\s*(.+)/i);
  const subjectMatch = output.match(/FOLLOWUP_SUBJECT:\s*(.+)/i);
  const bodyMatch = output.match(/FOLLOWUP_BODY:\s*([\s\S]*)$/i);

  return {
    aiScore: Number(scoreMatch?.[1] || 0),
    aiSummary: summaryMatch?.[1]?.trim() || "",
    aiNextStep: nextStepMatch?.[1]?.trim() || "",
    aiFollowupSubject: subjectMatch?.[1]?.trim() || "",
    aiFollowupBody: bodyMatch?.[1]?.trim() || "",
  };
}

async function generateWorkshopAutomation({ title, type, description, scheduleText, durationText, levelText }) {
  if (!GEMINI_API_KEY) {
    return {
      aiWorkshopDescription: "",
      aiAnnouncement: "",
      aiSocialPosts: "",
    };
  }

  const output = await callGemini({
    instructions:
      "You are SkillNest's internal AI marketing assistant. " +
      "Create ready-to-use marketing assets for a workshop. " +
      "Return exactly these sections: WORKSHOP_DESCRIPTION:, ANNOUNCEMENT:, SOCIAL_POSTS:. " +
      "Keep it polished and practical. " +
      "Do not invent prices, venues, or extra details not provided.",
    contents: [
      {
        role: "user",
        parts: [
          {
            text:
              `Title: ${title}\n` +
              `Type: ${type}\n` +
              `Description: ${description}\n` +
              `Schedule: ${scheduleText}\n` +
              `Duration: ${durationText}\n` +
              `Level: ${levelText}\n` +
              `Brand: SkillNest, Pune, Maharashtra. Knowledge is the power.\n`,
          },
        ],
      },
    ],
  });

  const descriptionMatch = output.match(/WORKSHOP_DESCRIPTION:\s*([\s\S]*?)ANNOUNCEMENT:/i);
  const announcementMatch = output.match(/ANNOUNCEMENT:\s*([\s\S]*?)SOCIAL_POSTS:/i);
  const socialMatch = output.match(/SOCIAL_POSTS:\s*([\s\S]*)$/i);

  return {
    aiWorkshopDescription: descriptionMatch?.[1]?.trim() || "",
    aiAnnouncement: announcementMatch?.[1]?.trim() || "",
    aiSocialPosts: socialMatch?.[1]?.trim() || "",
  };
}

async function handleChat(request, response) {
  try {
    if (!GEMINI_API_KEY) {
      sendJson(response, 500, {
        error:
          "GEMINI_API_KEY is not set. Add it to your environment before starting the local server.",
      });
      return;
    }

    const body = await parseJsonBody(request);
    const sessionId = String(body.sessionId || "anonymous").trim();
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const latestUserMessage = String(body.message || "").trim();
    const chatMode = String(body.mode || "default").trim().toLowerCase();

    if (!messages.length || !latestUserMessage) {
      sendJson(response, 400, { error: "A session, history, and latest message are required." });
      return;
    }

    const baseInstructions =
      "You are SkillNest AI, the admissions and learner guidance assistant for SkillNest in Pune, Maharashtra. " +
      "SkillNest offers Cloud, Data Analysis, AI, and Cybersecurity trainings plus free and paid workshops. " +
      "Primary audience: college students, freshers, early professionals, and knowledge seekers. " +
      "Keep replies concise, warm, practical, and conversion-aware. " +
      "Do not invent prices, schedules, certifications, job guarantees, or promises that are not provided. " +
      "If asked for location, say SkillNest is based in Pune, Maharashtra. " +
      "If asked who SkillNest is for, mention college students, freshers, early professionals, and knowledge seekers. " +
      "When a user shows buying intent, wants to enroll, asks for dates, fees, next batch, or deeper details not present in site context, tell them to contact SkillNest directly at phone 9284543320, email nileshdgaikwad8805@gmail.com, or WhatsApp.";

    const counselorInstructions =
      baseInstructions +
      " You are acting as a smart counselor. " +
      "Read the learner profile in the conversation carefully and recommend the single best starting path. " +
      "Use the learner's stage, interest area, and goal to choose between a free workshop, paid workshop, or full training track. " +
      "Briefly explain why that recommendation fits them, then mention one logical next alternative. " +
      "End with a soft next step toward Contact or WhatsApp.";

    const defaultInstructions =
      baseInstructions +
      " Your job is to guide visitors toward the right training or workshop, answer clearly, and help convert interest into inquiry. " +
      "When a user seems unsure, recommend the best starting option based on their stage. " +
      "End high-intent replies with a soft call to action such as inviting the learner to use Contact or WhatsApp.";

    const contents = messages.map((message) => ({
      role: message.role === "assistant" ? "model" : "user",
      parts: [{ text: String(message.content || "") }],
    }));

    const reply =
      (await callGemini({
        instructions: chatMode === "counselor" ? counselorInstructions : defaultInstructions,
        contents,
      })) || "I could not generate a reply right now. Please try again.";

    insertChatMessage.run(sessionId, "user", latestUserMessage);
    insertChatMessage.run(sessionId, "assistant", reply);

    sendJson(response, 200, {
      reply,
      model: GEMINI_MODEL,
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

async function handleAdminAiContent(request, response) {
  const session = requireAdmin(request, response);
  if (!session) {
    return;
  }

  try {
    if (!GEMINI_API_KEY) {
      sendJson(response, 500, { error: "GEMINI_API_KEY is not configured." });
      return;
    }

    const body = await parseJsonBody(request);
    const format = String(body.format || "").trim();
    const topic = String(body.topic || "").trim();
    const audience = String(body.audience || "").trim();
    const goal = String(body.goal || "").trim();
    const tone = String(body.tone || "professional").trim();

    if (!format || !topic || !audience || !goal) {
      sendJson(response, 400, { error: "Format, topic, audience, and goal are required." });
      return;
    }

    const instructions =
      "You are SkillNest's internal AI content assistant for admins. " +
      "Generate polished marketing content for a training brand in Pune offering Cloud, Data Analysis, AI, Cybersecurity, and workshop-based learning. " +
      "Write in a premium, practical, human tone. " +
      "Keep the output ready to use, specific, and clear. " +
      "Do not invent dates, fees, workshop seats, certifications, outcomes, or client names that were not provided. " +
      "If needed, use placeholders like [add date] or [add venue]. " +
      "Return only the requested content, with light formatting. " +
      "If format is workshop_description, produce a title, short intro, 4 bullet highlights, who it is for, and a CTA. " +
      "If format is announcement, produce a short promotional announcement suitable for website or WhatsApp broadcast. " +
      "If format is social_post, produce 3 distinct social post drafts with short captions and CTA lines.";

    const prompt =
      `Format: ${format}\n` +
      `Topic: ${topic}\n` +
      `Audience: ${audience}\n` +
      `Goal: ${goal}\n` +
      `Tone: ${tone}\n` +
      `Brand message: Knowledge is the power.\n` +
      `Location: Pune, Maharashtra.\n`;

    const output = await callGemini({
      instructions,
      contents: [
        {
          role: "user",
          parts: [{ text: prompt }],
        },
      ],
    });

    sendJson(response, 200, { success: true, output });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unable to generate AI content.",
    });
  }
}

async function handleContactInquiry(request, response) {
  try {
    const body = await parseJsonBody(request);
    const name = String(body.name || "").trim();
    const email = String(body.email || "").trim();
    const organization = String(body.organization || "").trim();
    const interest = String(body.interest || "").trim();
    const message = String(body.message || "").trim();
    const source = String(body.source || "contact_form").trim();

    if (!name || !email || !interest || !message) {
      sendJson(response, 400, {
        error: "Name, email, interest, and message are required.",
      });
      return;
    }

    const { aiScore, aiSummary, aiNextStep, aiFollowupSubject, aiFollowupBody } = await generateInquiryAutomation({
      name,
      organization,
      interest,
      message,
    });

    const aiFollowupSent = (await sendAutomatedFollowup({
      to: email,
      subject: aiFollowupSubject,
      body: aiFollowupBody,
    }))
      ? 1
      : 0;
    const nurtureStage = 0;
    const nurtureNextRunAt = aiFollowupSent ? toIsoDateOffset(NURTURE_DELAYS_DAYS[0]) : "";
    const nurtureLastSentAt = aiFollowupSent ? nowIso() : "";

    const result = insertInquiry.run(
      name,
      email,
      organization,
      interest,
      message,
      source,
      aiScore,
      aiSummary,
      aiNextStep,
      aiFollowupSubject,
      aiFollowupBody,
      aiFollowupSent,
      nurtureStage,
      nurtureNextRunAt,
      nurtureLastSentAt
    );
    const inquiryId = Number(result.lastInsertRowid);

    await notifyInquirySaved({
      name,
      email,
      organization,
      interest,
      message,
      source,
      inquiryId,
      aiSummary,
      aiNextStep,
    });

    sendJson(response, 201, {
      success: true,
      inquiryId,
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

async function handleLeadCapture(request, response) {
  try {
    const body = await parseJsonBody(request);
    const sessionId = String(body.sessionId || "").trim();
    const name = String(body.name || "").trim();
    const contact = String(body.contact || "").trim();
    const learnerType = String(body.learnerType || "").trim();
    const interest = String(body.interest || "").trim();
    const status = "new";
    const notes = "";

    if (!name || !contact || !learnerType || !interest) {
      sendJson(response, 400, {
        error: "Name, contact, learner type, and interest are required.",
      });
      return;
    }

    const { aiScore, aiSummary, aiNextStep, aiFollowupSubject, aiFollowupBody } = await generateLeadAutomation({
      name,
      learnerType,
      interest,
      contact,
    });

    const leadEmail = extractEmailAddress(contact);
    const aiFollowupSent = (await sendAutomatedFollowup({
      to: leadEmail,
      subject: aiFollowupSubject,
      body: aiFollowupBody,
    }))
      ? 1
      : 0;
    const computedStatus = aiFollowupSent ? "contacted" : status;
    const nurtureStage = 0;
    const nurtureNextRunAt = aiFollowupSent ? toIsoDateOffset(NURTURE_DELAYS_DAYS[0]) : "";
    const nurtureLastSentAt = aiFollowupSent ? nowIso() : "";

    const result = insertLead.run(
      sessionId,
      name,
      contact,
      learnerType,
      interest,
      computedStatus,
      notes,
      aiScore,
      aiSummary,
      aiNextStep,
      aiFollowupSubject,
      aiFollowupBody,
      aiFollowupSent,
      nurtureStage,
      nurtureNextRunAt,
      nurtureLastSentAt
    );
    const leadId = Number(result.lastInsertRowid);

    await notifyLeadSaved({
      name,
      contact,
      learnerType,
      interest,
      leadId,
      status: computedStatus,
      aiSummary,
      aiNextStep,
    });

    sendJson(response, 201, {
      success: true,
      leadId,
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

function handleAdminOverview(request, response) {
  const session = requireAdmin(request, response);
  if (!session) {
    return;
  }

  try {
    sendJson(response, 200, {
      session: {
        username: session.username,
      },
      counts: {
        inquiries: selectInquiryCount.get().count,
        leads: selectLeadCount.get().count,
        chatMessages: selectChatCount.get().count,
        workshops: selectWorkshopCount.get().count,
        enrollments: selectEnrollmentCount.get().count,
      },
      notifications: {
        enabled: resendConfigured,
        recipient: NOTIFY_EMAIL_TO || "Not configured",
      },
      inquiries: selectRecentInquiries.all(),
      leads: selectRecentLeads.all(),
      chatMessages: selectRecentChats.all(),
      workshops: selectWorkshops.all(),
      enrollments: selectRecentEnrollments.all(),
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

async function handleAdminLogin(request, response) {
  try {
    const body = await parseJsonBody(request);
    const username = String(body.username || "").trim();
    const password = String(body.password || "").trim();
    const adminUser = selectAdminUser.get();

    if (!adminUser || adminUser.username !== username || !verifyPassword(password, adminUser.password_hash)) {
      sendJson(response, 401, { error: "Invalid admin credentials." });
      return;
    }

    const token = crypto.randomUUID();
    adminSessions.set(token, {
      id: adminUser.id,
      username: adminUser.username,
      createdAt: Date.now(),
    });

    sendJson(
      response,
      200,
      { success: true, username: adminUser.username, token },
      {
        "Set-Cookie": `${SESSION_COOKIE}=${encodeURIComponent(token)}; HttpOnly; Path=/; SameSite=Lax`,
      }
    );
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

function handleAdminLogout(request, response) {
  const authorization = request.headers.authorization || "";
  const headerToken = authorization.startsWith("Bearer ")
    ? authorization.slice("Bearer ".length).trim()
    : "";
  const cookies = parseCookies(request);
  const token = headerToken || cookies[SESSION_COOKIE];
  if (token) {
    adminSessions.delete(token);
  }

  sendJson(
    response,
    200,
    { success: true },
    {
      "Set-Cookie": `${SESSION_COOKIE}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax`,
    }
  );
}

function handleAdminSession(request, response) {
  const session = getAdminSession(request);
  if (!session) {
    sendJson(response, 401, { authenticated: false });
    return;
  }

  sendJson(response, 200, {
    authenticated: true,
    username: session.username,
  });
}

async function handleAdminChangePassword(request, response) {
  const session = requireAdmin(request, response);
  if (!session) {
    return;
  }

  try {
    const body = await parseJsonBody(request);
    const currentPassword = String(body.currentPassword || "").trim();
    const newPassword = String(body.newPassword || "").trim();
    const confirmPassword = String(body.confirmPassword || "").trim();
    const adminUser = selectAdminUser.get();

    if (!adminUser || adminUser.id !== session.id) {
      sendJson(response, 401, { error: "Admin session is invalid." });
      return;
    }

    if (!verifyPassword(currentPassword, adminUser.password_hash)) {
      sendJson(response, 400, { error: "Current password is incorrect." });
      return;
    }

    if (newPassword.length < 8) {
      sendJson(response, 400, { error: "New password must be at least 8 characters." });
      return;
    }

    if (newPassword !== confirmPassword) {
      sendJson(response, 400, { error: "New password and confirm password must match." });
      return;
    }

    updateAdminPassword.run(createPasswordHash(newPassword), adminUser.id);
    sendJson(response, 200, { success: true });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

function handleWorkshopList(_request, response) {
  sendJson(response, 200, {
    workshops: selectPublicWorkshops.all(),
  });
}

function handleProductCatalog(_request, response) {
  sendJson(response, 200, {
    products: PRODUCT_CATALOG,
    razorpayEnabled: razorpayConfigured,
    razorpayKeyId: razorpayConfigured ? RAZORPAY_KEY_ID : "",
  });
}

async function handleFreeEnrollment(request, response) {
  try {
    const body = await parseJsonBody(request);
    const productId = String(body.productId || "").trim();
    const learnerName = String(body.name || "").trim();
    const learnerEmail = String(body.email || "").trim();
    const learnerPhone = String(body.phone || "").trim();
    const learnerType = String(body.learnerType || "").trim();
    const learnerGoal = String(body.goal || "").trim();
    const product = getProductById(productId);

    if (!product || product.type !== "free") {
      sendJson(response, 400, { error: "Invalid free product selection." });
      return;
    }

    if (!learnerName || !learnerEmail || !learnerPhone || !learnerType) {
      sendJson(response, 400, { error: "Name, email, phone, and learner type are required." });
      return;
    }

    const accessToken = crypto.randomUUID();
    const result = insertEnrollment.run(
      product.id,
      product.name,
      product.type,
      product.priceInr,
      "INR",
      learnerName,
      learnerEmail,
      learnerPhone,
      learnerType,
      learnerGoal,
      "enrolled",
      "free",
      "",
      accessToken,
      0
    );

    const enrollment = selectEnrollmentById.get(Number(result.lastInsertRowid));
    await sendLearnerOnboardingEmail({ request, enrollment });

    sendJson(response, 201, {
      success: true,
      enrollmentId: enrollment.id,
      accessToken: enrollment.access_token,
      redirectUrl: `/learner-dashboard.html?token=${encodeURIComponent(enrollment.access_token)}`,
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unable to complete free registration.",
    });
  }
}

async function handleRazorpayOrderCreate(request, response) {
  try {
    if (!razorpayConfigured) {
      sendJson(response, 503, { error: "Razorpay is not configured yet." });
      return;
    }

    const body = await parseJsonBody(request);
    const productId = String(body.productId || "").trim();
    const learnerName = String(body.name || "").trim();
    const learnerEmail = String(body.email || "").trim();
    const learnerPhone = String(body.phone || "").trim();
    const learnerType = String(body.learnerType || "").trim();
    const learnerGoal = String(body.goal || "").trim();
    const product = getProductById(productId);

    if (!product || product.type !== "paid") {
      sendJson(response, 400, { error: "Invalid paid product selection." });
      return;
    }

    if (!learnerName || !learnerEmail || !learnerPhone || !learnerType) {
      sendJson(response, 400, { error: "Name, email, phone, and learner type are required." });
      return;
    }

    const accessToken = crypto.randomUUID();
    const insertResult = insertEnrollment.run(
      product.id,
      product.name,
      product.type,
      product.priceInr,
      "INR",
      learnerName,
      learnerEmail,
      learnerPhone,
      learnerType,
      learnerGoal,
      "payment_pending",
      "razorpay",
      "",
      accessToken,
      0
    );
    const enrollmentId = Number(insertResult.lastInsertRowid);

    const order = await createRazorpayOrder({
      amountInr: product.priceInr,
      receipt: `skillnest_${enrollmentId}`,
      notes: {
        enrollment_id: String(enrollmentId),
        product_id: product.id,
        learner_email: learnerEmail,
      },
    });

    updateEnrollmentOrder.run(String(order.id || ""), enrollmentId);

    sendJson(response, 201, {
      success: true,
      enrollmentId,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: RAZORPAY_KEY_ID,
      product,
      learner: {
        name: learnerName,
        email: learnerEmail,
        contact: learnerPhone,
      },
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unable to create Razorpay order.",
    });
  }
}

async function handleRazorpayVerify(request, response) {
  try {
    const body = await parseJsonBody(request);
    const enrollmentId = Number(body.enrollmentId || 0);
    const orderId = String(body.razorpay_order_id || "").trim();
    const paymentId = String(body.razorpay_payment_id || "").trim();
    const signature = String(body.razorpay_signature || "").trim();

    if (!enrollmentId || !orderId || !paymentId || !signature) {
      sendJson(response, 400, { error: "Payment verification details are required." });
      return;
    }

    const enrollment = selectEnrollmentById.get(enrollmentId);
    if (!enrollment) {
      sendJson(response, 404, { error: "Enrollment not found." });
      return;
    }

    if (enrollment.provider_order_id !== orderId) {
      sendJson(response, 400, { error: "Payment order mismatch." });
      return;
    }

    if (!verifyRazorpaySignature({ orderId, paymentId, signature })) {
      sendJson(response, 400, { error: "Invalid payment signature." });
      return;
    }

    updateEnrollmentPayment.run("enrolled", paymentId, signature, enrollmentId);
    const updatedEnrollment = selectEnrollmentById.get(enrollmentId);
    await sendLearnerOnboardingEmail({ request, enrollment: updatedEnrollment });

    sendJson(response, 200, {
      success: true,
      redirectUrl: `/payment-success.html?token=${encodeURIComponent(updatedEnrollment.access_token)}`,
      accessToken: updatedEnrollment.access_token,
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unable to verify payment.",
    });
  }
}

function handleLearnerSession(request, response, requestUrl) {
  const token = String(requestUrl.searchParams.get("token") || "").trim();
  if (!token) {
    sendJson(response, 400, { error: "Learner token is required." });
    return;
  }

  const enrollment = selectEnrollmentByToken.get(token);
  if (!enrollment) {
    sendJson(response, 404, { error: "Learner session not found." });
    return;
  }

  sendJson(response, 200, {
    enrollment: {
      id: enrollment.id,
      productName: enrollment.product_name,
      productType: enrollment.product_type,
      amountInr: enrollment.amount_inr,
      learnerName: enrollment.learner_name,
      learnerEmail: enrollment.learner_email,
      learnerPhone: enrollment.learner_phone,
      learnerType: enrollment.learner_type,
      learnerGoal: enrollment.learner_goal,
      status: enrollment.status,
      onboardingSent: Boolean(enrollment.onboarding_sent),
      createdAt: enrollment.created_at,
    },
  });
}

async function handleAdminWorkshopCreate(request, response) {
  if (!requireAdmin(request, response)) {
    return;
  }

  try {
    const body = await parseJsonBody(request);
    const title = String(body.title || "").trim();
    const type = String(body.type || "").trim();
    const description = String(body.description || "").trim();
    const scheduleText = String(body.scheduleText || "").trim();
    const durationText = String(body.durationText || "").trim();
    const levelText = String(body.levelText || "").trim();
    const ctaText = String(body.ctaText || "").trim();
    const ctaLink = String(body.ctaLink || "").trim() || "contact.html";
    const isActive = body.isActive ? 1 : 0;

    if (!title || !type || !description || !scheduleText || !durationText || !levelText || !ctaText) {
      sendJson(response, 400, { error: "All workshop fields are required." });
      return;
    }

    const aiAssets = await generateWorkshopAutomation({
      title,
      type,
      description,
      scheduleText,
      durationText,
      levelText,
    });

    const result = insertWorkshop.run(
      title,
      type,
      description,
      scheduleText,
      durationText,
      levelText,
      ctaText,
      ctaLink,
      aiAssets.aiWorkshopDescription,
      aiAssets.aiAnnouncement,
      aiAssets.aiSocialPosts,
      isActive
    );

    sendJson(response, 201, {
      success: true,
      workshopId: Number(result.lastInsertRowid),
    });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

async function handleAdminWorkshopUpdate(request, response, workshopId) {
  if (!requireAdmin(request, response)) {
    return;
  }

  try {
    const body = await parseJsonBody(request);
    const title = String(body.title || "").trim();
    const type = String(body.type || "").trim();
    const description = String(body.description || "").trim();
    const scheduleText = String(body.scheduleText || "").trim();
    const durationText = String(body.durationText || "").trim();
    const levelText = String(body.levelText || "").trim();
    const ctaText = String(body.ctaText || "").trim();
    const ctaLink = String(body.ctaLink || "").trim() || "contact.html";
    const isActive = body.isActive ? 1 : 0;

    if (!title || !type || !description || !scheduleText || !durationText || !levelText || !ctaText) {
      sendJson(response, 400, { error: "All workshop fields are required." });
      return;
    }

    const existingWorkshop = selectWorkshopById.get(workshopId);
    if (!existingWorkshop) {
      sendJson(response, 404, { error: "Workshop not found." });
      return;
    }

    const aiAssets = await generateWorkshopAutomation({
      title,
      type,
      description,
      scheduleText,
      durationText,
      levelText,
    });

    updateWorkshop.run(
      title,
      type,
      description,
      scheduleText,
      durationText,
      levelText,
      ctaText,
      ctaLink,
      aiAssets.aiWorkshopDescription,
      aiAssets.aiAnnouncement,
      aiAssets.aiSocialPosts,
      isActive,
      workshopId
    );

    sendJson(response, 200, { success: true });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

function handleAdminWorkshopDelete(request, response, workshopId) {
  if (!requireAdmin(request, response)) {
    return;
  }

  try {
    deleteWorkshop.run(workshopId);
    sendJson(response, 200, { success: true });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

async function handleAdminLeadUpdate(request, response, leadId) {
  if (!requireAdmin(request, response)) {
    return;
  }

  try {
    const body = await parseJsonBody(request);
    const status = String(body.status || "").trim().toLowerCase();
    const notes = String(body.notes || "").trim();
    const allowedStatuses = ["new", "contacted", "qualified", "enrolled", "closed"];

    if (!allowedStatuses.includes(status)) {
      sendJson(response, 400, { error: "Invalid lead status." });
      return;
    }

    updateLeadStatus.run(status, notes, leadId);
    sendJson(response, 200, { success: true });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

async function handleAdminTestEmail(request, response) {
  if (!requireAdmin(request, response)) {
    return;
  }

  try {
    if (!resendConfigured) {
      sendJson(response, 400, {
        error: "Email notifications are not configured yet. Add Resend settings to .env first.",
      });
      return;
    }

    await sendNotificationEmail({
      subject: "SkillNest notification test",
      text:
        "This is a SkillNest test email. Gmail SMTP is configured correctly if you received this message.",
      html:
        "<h2>SkillNest notification test</h2><p>Gmail SMTP is configured correctly if you received this message.</p>",
    });

    sendJson(response, 200, { success: true });
  } catch (error) {
    sendJson(response, 500, {
      error: error instanceof Error ? error.message : "Unexpected server error.",
    });
  }
}

function handleCsvExport(request, response, kind) {
  if (!requireAdmin(request, response)) {
    return;
  }

  const rows =
    kind === "inquiries"
      ? selectRecentInquiries.all()
      : kind === "leads"
        ? selectRecentLeads.all()
        : selectWorkshops.all();

  const csv = toCsv(rows);
  sendText(response, 200, csv, "text/csv; charset=utf-8", {
    "Content-Disposition": `attachment; filename="skillnest-${kind}.csv"`,
  });
}

function serveStatic(request, response, pathname) {
  if (pathname === "/admin.html" && !getAdminSession(request)) {
    response.writeHead(302, { Location: "/admin-login.html" });
    response.end();
    return;
  }

  const filePath = getSafeFilePath(pathname);
  const blockedFiles = new Set(["server.js", ".env", "package.json", "render.yaml", "netlify.toml", "vercel.json"]);

  if (!filePath.startsWith(ROOT)) {
    sendJson(response, 403, { error: "Forbidden" });
    return;
  }

  if (filePath.startsWith(DATA_DIR) || blockedFiles.has(path.basename(filePath)) || path.basename(filePath).startsWith(".")) {
    sendJson(response, 403, { error: "Forbidden" });
    return;
  }

  if (pathname === "/config.js") {
    sendText(response, 200, buildRuntimeClientConfig(request), "application/javascript; charset=utf-8");
    return;
  }

  fs.readFile(filePath, (error, fileBuffer) => {
    if (error) {
      if (error.code === "ENOENT") {
        sendText(response, 404, "Not found");
        return;
      }

      sendText(response, 500, "Server error");
      return;
    }

    const extension = path.extname(filePath).toLowerCase();
    response.writeHead(200, {
      "Content-Type": MIME_TYPES[extension] || "application/octet-stream",
    });
    response.end(fileBuffer);
  });
}

const server = http.createServer((request, response) => {
  applyCors(request, response);

  if (request.method === "OPTIONS") {
    response.writeHead(204);
    response.end();
    return;
  }

  const requestUrl = new URL(request.url, `http://${request.headers.host}`);
  const workshopMatch = requestUrl.pathname.match(/^\/api\/admin\/workshops\/(\d+)$/);
  const leadMatch = requestUrl.pathname.match(/^\/api\/admin\/leads\/(\d+)$/);

  if (request.method === "POST" && requestUrl.pathname === "/api/chat") {
    handleChat(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/contact") {
    handleContactInquiry(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/leads") {
    handleLeadCapture(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/admin/login") {
    handleAdminLogin(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/admin/logout") {
    handleAdminLogout(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/admin/change-password") {
    handleAdminChangePassword(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/admin/test-email") {
    handleAdminTestEmail(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/admin/ai-content") {
    handleAdminAiContent(request, response);
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/admin/session") {
    handleAdminSession(request, response);
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/health") {
    sendJson(response, 200, {
      ok: true,
      service: "skillnest",
      time: new Date().toISOString(),
    });
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/admin/overview") {
    handleAdminOverview(request, response);
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/workshops") {
    handleWorkshopList(request, response);
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/products") {
    handleProductCatalog(request, response);
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/learner/session") {
    handleLearnerSession(request, response, requestUrl);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/enrollments/free") {
    handleFreeEnrollment(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/payments/razorpay/order") {
    handleRazorpayOrderCreate(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/payments/razorpay/verify") {
    handleRazorpayVerify(request, response);
    return;
  }

  if (request.method === "POST" && requestUrl.pathname === "/api/admin/workshops") {
    handleAdminWorkshopCreate(request, response);
    return;
  }

  if (workshopMatch && request.method === "PUT") {
    handleAdminWorkshopUpdate(request, response, Number(workshopMatch[1]));
    return;
  }

  if (workshopMatch && request.method === "DELETE") {
    handleAdminWorkshopDelete(request, response, Number(workshopMatch[1]));
    return;
  }

  if (leadMatch && request.method === "PUT") {
    handleAdminLeadUpdate(request, response, Number(leadMatch[1]));
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/admin/export/inquiries.csv") {
    handleCsvExport(request, response, "inquiries");
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/admin/export/leads.csv") {
    handleCsvExport(request, response, "leads");
    return;
  }

  if (request.method === "GET" && requestUrl.pathname === "/api/admin/export/workshops.csv") {
    handleCsvExport(request, response, "workshops");
    return;
  }

  if (request.method === "GET") {
    serveStatic(request, response, requestUrl.pathname);
    return;
  }

  sendText(response, 405, "Method not allowed");
});

server.listen(PORT, HOST, () => {
  console.log(`SkillNest server running at http://${HOST}:${PORT}`);
  console.log(`Database ready at ${DB_PATH}`);
  console.log(`Platform target: ${APP_CONFIG.platformTarget} (${APP_CONFIG.runtimeMode})`);
  if (APP_CONFIG.enableBackgroundJobs) {
    runNurtureCycle();
    setInterval(runNurtureCycle, 5 * 60 * 1000);
  } else {
    console.log("Background jobs are disabled for this runtime.");
  }
});
